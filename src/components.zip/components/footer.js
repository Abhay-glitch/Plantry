import './footer.css';
function Footer() {
  return (
    <>
        <div id="footer">
          <h1>Footer Section </h1>
        </div>
    </>
      
     );
}

export default Footer;
