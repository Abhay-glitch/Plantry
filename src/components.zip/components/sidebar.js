import React from 'react'
import './sidebar.css';
function Sidebar() {
  return (
    <div id='sidebar'>
      
    </div>
  )
}

export default Sidebar
