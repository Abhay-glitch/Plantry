import './contact.css';
import React from 'react';
function Contact() {
    return (
      <>
       <div id="contact">
        <h1>Contact Page </h1>
      </div>
     
      </>
        
       );
  }
  
  export default Contact;