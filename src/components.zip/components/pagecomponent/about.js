import './about.css';
import React, { useState } from 'react';
function About() {

  const [mks, setMks] =useState([65, 58, 96, 56, 66, 75]);

    return (
      <>
       <div id="about">
        <h1>About Page</h1>
        {/* <h2>Manually showing data </h2>
        <p>mark 1:{mks[0]} </p>
        <p>mark 1:{mks[1]} </p>
        <p>mark 1:{mks[2]} </p>
        <p>mark 1:{mks[3]} </p>
        <p>mark 1:{mks[4]} </p>
        <p>mark 1:{mks[5]} </p> */}

        <h2>accessing data by loop</h2>
        {
          mks.map((val,ind)=>(
            <p> marks={ind}----{val} </p>
          ))
        }
        
      </div>
     
      </>
        
       );
  }
  
  export default About;