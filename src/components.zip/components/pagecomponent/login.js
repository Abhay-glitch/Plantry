import './login.css';
import React from 'react';
function Login() {
    return (
      <>
       <div id="login">
        <h1>Login Page</h1>
      </div>
     
      </>
        
       );
  }
  
  export default Login;