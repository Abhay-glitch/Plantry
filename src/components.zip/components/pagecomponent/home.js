import './home.css';
import React from 'react';
import { useState } from 'react';
function Home() {
  // syntax const [state variable, function to update state variable] = useState(initial value);
  const [a,setA]=useState(10);
  const [b,setB]=useState(20);
  const [count,setCount]=useState(0);
  const [date,setDate]=useState(Date());

  const increment=()=>{
    setCount(count+1);
  }
  const decreement=()=>{
    setCount(count-1);
  }

  setInterval((setDate)
,1000);

    return (
      <>
       <div id="home">
        <h1>Home Page</h1>
        <hr/>
        <h2>counter:{count}</h2>
        <button onClick={increment}>+</button>
        <button onClick={decreement}>-</button>
        <hr/>

        <p>Date:{date}</p>
        <hr/>


        <p>value of a={a}</p>
        <p>value of a={b}</p>
        <p>value of c={a+b}</p>
      </div>
     
      </>
        
       );
  }
  
  export default Home;