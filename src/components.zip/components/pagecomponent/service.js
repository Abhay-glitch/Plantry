import './service.css';
import React from 'react';
function Service() {
    return (
      <>
       <div id="service">
        <h1>Service Page</h1>
      </div>
     
      </>
        
       );
  }
  
  export default Service;