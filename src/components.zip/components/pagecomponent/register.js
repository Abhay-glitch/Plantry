import './home.css';
import React from 'react';
function Register() {
    return (
      <>
       <div id="register">
        <h1>Register Page</h1>
      </div>
     
      </>
        
       );
  }
  
  export default Register;